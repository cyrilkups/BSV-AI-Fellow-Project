from __future__ import annotations

from pathlib import Path
from xml.sax.saxutils import escape
import textwrap


ROOT = Path(__file__).resolve().parent
SCREENSHOTS = ROOT / "screenshots"
DIAGRAMS = ROOT / "diagrams"

CANVAS_WIDTH = 1400
CARD_PADDING = 48
LINE_HEIGHT = 28


def write(path: Path, content: str) -> None:
    path.write_text(content + "\n", encoding="utf-8")


def screenshot_svg(title: str, lines: list[str]) -> str:
    body_lines = [line.rstrip() for line in lines]
    height = 180 + max(14, len(body_lines)) * LINE_HEIGHT
    text_y = 120

    svg_lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{CANVAS_WIDTH}" height="{height}" viewBox="0 0 {CANVAS_WIDTH} {height}">',
        '  <rect width="100%" height="100%" fill="#f4f7fb"/>',
        '  <rect x="28" y="28" width="1344" height="{card_height}" rx="20" fill="#ffffff" stroke="#d7e0ea" stroke-width="2"/>'.format(
            card_height=height - 56
        ),
        '  <rect x="28" y="28" width="1344" height="64" rx="20" fill="#e9f0f7"/>',
        '  <rect x="28" y="72" width="1344" height="20" fill="#e9f0f7"/>',
        '  <circle cx="62" cy="60" r="8" fill="#ff6b6b"/>',
        '  <circle cx="88" cy="60" r="8" fill="#ffd166"/>',
        '  <circle cx="114" cy="60" r="8" fill="#4ecdc4"/>',
        f'  <text x="150" y="67" font-family="Menlo, Monaco, Consolas, monospace" font-size="28" font-weight="700" fill="#18324a">{escape(title)}</text>',
    ]

    for line in body_lines:
        y = text_y
        svg_lines.append(
            f'  <text x="{CARD_PADDING + 36}" y="{y}" font-family="Menlo, Monaco, Consolas, monospace" font-size="24" fill="#16283a">{escape(line or " ")}</text>'
        )
        text_y += LINE_HEIGHT

    svg_lines.append("</svg>")
    return "\n".join(svg_lines)


def arrow(x1: int, y1: int, x2: int, y2: int, color: str = "#4f6f8f") -> str:
    return "\n".join(
        [
            f'  <line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="5" stroke-linecap="round"/>',
            f'  <polygon points="{x2},{y2} {x2 - 18},{y2 - 10} {x2 - 18},{y2 + 10}" fill="{color}"/>',
        ]
    )


def vertical_arrow(x: int, y1: int, y2: int, color: str = "#4f6f8f") -> str:
    return "\n".join(
        [
            f'  <line x1="{x}" y1="{y1}" x2="{x}" y2="{y2}" stroke="{color}" stroke-width="5" stroke-linecap="round"/>',
            f'  <polygon points="{x},{y2} {x - 10},{y2 - 18} {x + 10},{y2 - 18}" fill="{color}"/>',
        ]
    )


def elbow_arrow(
    x1: int,
    y1: int,
    mid_x: int,
    mid_y: int,
    x2: int,
    y2: int,
    color: str = "#4f6f8f",
) -> str:
    return "\n".join(
        [
            f'  <polyline points="{x1},{y1} {mid_x},{y1} {mid_x},{mid_y} {x2},{mid_y} {x2},{y2}" fill="none" stroke="{color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>',
            f'  <polygon points="{x2},{y2} {x2 - 10},{y2 - 18} {x2 + 10},{y2 - 18}" fill="{color}"/>',
        ]
    )


def wrap_label(text: str, width: int) -> list[str]:
    normalized = " ".join(text.split())
    return textwrap.wrap(normalized, width=width, break_long_words=False) or [normalized]


def rounded_box(
    x: int,
    y: int,
    w: int,
    h: int,
    fill: str,
    title: str,
    subtitle: str | None = None,
    title_size: int = 24,
) -> str:
    title_lines = wrap_label(title, max(10, int(w / 15)))
    subtitle_lines = wrap_label(subtitle, max(14, int(w / 13))) if subtitle else []
    all_lines = [(line, title_size, 700) for line in title_lines]
    all_lines.extend((line, 16, 500) for line in subtitle_lines)

    line_height = 28
    subtitle_height = 22
    total_height = 0
    for _, font_size, _ in all_lines:
        total_height += line_height if font_size >= 20 else subtitle_height

    current_y = y + (h - total_height) / 2 + 8
    text_parts = []
    for line, font_size, weight in all_lines:
        text_parts.append(
            f'  <text x="{x + w / 2}" y="{current_y}" text-anchor="middle" '
            f'font-family="Avenir Next, Helvetica, Arial, sans-serif" font-size="{font_size}" '
            f'font-weight="{weight}" fill="#173042">{escape(line)}</text>'
        )
        current_y += line_height if font_size >= 20 else subtitle_height

    return "\n".join(
        [
            f'  <rect x="{x}" y="{y}" width="{w}" height="{h}" rx="18" fill="{fill}" stroke="#29445d" stroke-width="2"/>',
            *text_parts,
        ]
    )


def diagram_shell(title: str, inner: str, height: int = 420) -> str:
    return "\n".join(
        [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="{height}" viewBox="0 0 1400 {height}">',
            '  <rect width="100%" height="100%" fill="#f8fbfd"/>',
            '  <text x="60" y="60" font-family="Avenir Next, Helvetica, Arial, sans-serif" font-size="34" font-weight="800" fill="#18324a">{}</text>'.format(
                escape(title)
            ),
            inner,
            "</svg>",
        ]
    )


def build_architecture_diagram() -> str:
    parts = [
        rounded_box(60, 160, 210, 120, "#e3f2fd", "Input startup descriptions", title_size=22),
        rounded_box(320, 160, 250, 120, "#e9f7ef", "Typed extraction layer", "BAML schema and field normalization", title_size=22),
        rounded_box(620, 160, 240, 120, "#fff4d6", "LLM or mock provider", "live model path or benchmark path", title_size=22),
        rounded_box(910, 160, 210, 120, "#f3e8ff", "Structured JSON output", title_size=22),
        rounded_box(1170, 160, 170, 120, "#ffe8e8", "Evaluator", "validity, consistency, failures", title_size=22),
        rounded_box(1100, 350, 280, 110, "#dff4ff", "Evaluation summary", "used in the BAML diligence writeup", title_size=24),
        arrow(270, 220, 320, 220),
        arrow(570, 220, 620, 220),
        arrow(860, 220, 910, 220),
        arrow(1120, 220, 1170, 220),
        vertical_arrow(1240, 280, 350),
    ]
    return diagram_shell("Architecture Diagram", "\n".join(parts), height=520)


def build_workflow_diagram() -> str:
    parts: list[str] = [
        rounded_box(70, 120, 240, 110, "#e3f2fd", "Select company"),
        rounded_box(380, 120, 240, 110, "#e9f7ef", "Form thesis"),
        rounded_box(690, 120, 240, 110, "#fff4d6", "Build prototype"),
        rounded_box(1000, 120, 240, 110, "#ffe8e8", "Test clean inputs"),
        rounded_box(1000, 310, 240, 110, "#f3e8ff", "Test messy inputs"),
        rounded_box(690, 310, 240, 110, "#dff4ff", "Test adversarial inputs"),
        rounded_box(380, 310, 240, 110, "#fef3c7", "Evaluate failures"),
        rounded_box(70, 310, 240, 110, "#dcfce7", "Write diligence"),
        arrow(310, 175, 380, 175),
        arrow(620, 175, 690, 175),
        arrow(930, 175, 1000, 175),
        vertical_arrow(1120, 230, 310),
        arrow(1000, 365, 930, 365),
        arrow(690, 365, 620, 365),
        arrow(380, 365, 310, 365),
    ]
    return diagram_shell("Workflow Diagram", "\n".join(parts), height=500)


def main() -> None:
    screenshot_map = {
        "setup_terminal": ("Prototype Test Run", SCREENSHOTS / "source_setup_terminal.txt"),
        "successful_extraction": ("Successful Structured Extraction", SCREENSHOTS / "source_successful_extraction.txt"),
        "failure_case": ("Failure Case From Raw Baseline", SCREENSHOTS / "source_failure_case.txt"),
        "final_output": ("Evaluation Summary Snapshot", SCREENSHOTS / "source_final_output.txt"),
    }

    for stem, (title, source_path) in screenshot_map.items():
        lines = source_path.read_text(encoding="utf-8").splitlines()
        write(SCREENSHOTS / f"{stem}.svg", screenshot_svg(title, lines))

    write(DIAGRAMS / "architecture_diagram.svg", build_architecture_diagram())
    write(DIAGRAMS / "workflow_diagram.svg", build_workflow_diagram())


if __name__ == "__main__":
    main()
