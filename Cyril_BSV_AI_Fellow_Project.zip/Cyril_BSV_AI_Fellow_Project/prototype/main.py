from __future__ import annotations

import argparse
from pathlib import Path

from core import run_dataset, save_json


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the Startup Signal Extractor prototype.")
    parser.add_argument(
        "--provider",
        default="mock",
        choices=["mock"],
        help="Provider mode. The offline mock path is the only runnable mode in this environment.",
    )
    parser.add_argument(
        "--runs",
        type=int,
        default=3,
        help="Number of repeated runs used to measure consistency and baseline fragility.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    project_root = Path(__file__).resolve().parent
    input_dir = project_root / "input_examples"
    output_dir = project_root / "outputs"

    dataset_map = {
        "clean_startup_descriptions.json": "clean_run_output.json",
        "messy_startup_descriptions.json": "messy_run_output.json",
        "adversarial_startup_descriptions.json": "adversarial_run_output.json",
    }

    for input_name, output_name in dataset_map.items():
        result = run_dataset(input_dir / input_name, provider_mode=args.provider, repeated_runs=args.runs)
        save_json(output_dir / output_name, result)
        print(f"Wrote {output_name} with {len(result['items'])} extracted samples.")

    print("Startup Signal Extractor run completed.")


if __name__ == "__main__":
    main()
