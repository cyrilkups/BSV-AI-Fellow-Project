# Screenshot Capture Instructions

Capture the following images after you run the prototype:

1. `setup_terminal.png`
   Show the terminal after installing requirements and before the first run, with the `prototype/` directory visible.
2. `successful_extraction.png`
   Show a clean run finishing successfully and the top of `outputs/clean_run_output.json`.
3. `failure_case.png`
   Show either an adversarial sample in `outputs/adversarial_run_output.json` or the evaluator surfacing raw baseline failure modes.
4. `final_output.png`
   Show `outputs/evaluation_summary.md` rendered in the editor.
5. Optional extra capture for the written submission
   Grab a VS Code file tree screenshot so reviewers can see the full package layout.
