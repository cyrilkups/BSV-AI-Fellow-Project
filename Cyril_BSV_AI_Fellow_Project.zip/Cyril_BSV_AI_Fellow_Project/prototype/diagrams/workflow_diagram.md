# Workflow Diagram

```mermaid
flowchart LR
    A["Select company"] --> B["Form thesis"]
    B --> C["Build prototype"]
    C --> D["Test clean inputs"]
    D --> E["Test messy inputs"]
    E --> F["Test adversarial inputs"]
    F --> G["Evaluate failures"]
    G --> H["Write diligence"]
```
