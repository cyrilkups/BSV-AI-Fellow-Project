# Architecture Diagram

```mermaid
flowchart LR
    A["Input startup descriptions"] --> B["BAML or typed extraction layer"]
    B --> C["LLM call or offline mock provider"]
    C --> D["Structured JSON output"]
    D --> E["Evaluator"]
    E --> F["Diligence summary"]
```
