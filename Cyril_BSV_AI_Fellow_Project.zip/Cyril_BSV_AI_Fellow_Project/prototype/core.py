from __future__ import annotations

import copy
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


REQUIRED_FIELDS = [
    "company_name",
    "website",
    "category",
    "target_customer",
    "product_summary",
    "ai_native_score",
    "developer_tool_relevance",
    "adoption_friction",
    "likely_buyer",
    "key_risk",
    "diligence_notes",
]

INT_FIELDS = {
    "ai_native_score",
    "developer_tool_relevance",
    "adoption_friction",
}


KNOWN_COMPANIES = {
    "baml": "BAML",
    "boundaryml": "BAML",
    "mem0": "Mem0",
    "tigris": "Tigris Data",
    "parasail": "Parasail",
    "atuin": "Atuin",
    "primitive": "Primitive",
    "rasa": "Rasa",
    "entire": "Entire",
}


COMPANY_PROFILES: dict[str, dict[str, Any]] = {
    "BAML": {
        "keywords": ["typed", "schema", "structured output", "prompt", "llm", "agent"],
        "category": "typed LLM interface and structured extraction framework",
        "target_customer": "AI engineers and product engineers shipping LLM features",
        "ai_native_score": 5,
        "developer_tool_relevance": 5,
        "adoption_friction": 3,
        "likely_buyer": "engineering lead or AI platform lead",
        "key_risk": "Model vendors and adjacent frameworks may absorb more native structured output features.",
    },
    "Mem0": {
        "keywords": ["memory", "agent", "context", "retrieval", "personalization"],
        "category": "memory infrastructure for persistent AI agents",
        "target_customer": "AI teams building copilots, assistants, and long-lived workflows",
        "ai_native_score": 5,
        "developer_tool_relevance": 4,
        "adoption_friction": 4,
        "likely_buyer": "AI platform lead or staff engineer",
        "key_risk": "Memory can become crowded and platform-dependent if model providers bundle the core primitives.",
    },
    "Tigris Data": {
        "keywords": ["object storage", "storage", "s3", "database", "data infra"],
        "category": "object storage and developer-facing data infrastructure",
        "target_customer": "developers building data-heavy apps and AI workloads",
        "ai_native_score": 4,
        "developer_tool_relevance": 4,
        "adoption_friction": 3,
        "likely_buyer": "infrastructure lead or backend engineering manager",
        "key_risk": "Incumbent cloud platforms are strong and pricing pressure can compress differentiation.",
    },
    "Parasail": {
        "keywords": ["compute", "gpu", "cluster", "inference", "orchestration"],
        "category": "AI compute and infrastructure orchestration",
        "target_customer": "teams running training or inference workloads with variable demand",
        "ai_native_score": 5,
        "developer_tool_relevance": 4,
        "adoption_friction": 4,
        "likely_buyer": "head of infrastructure or ML platform lead",
        "key_risk": "Margin durability and adoption depend on whether the product wins on cost, reliability, or workflow fit.",
    },
    "Atuin": {
        "keywords": ["shell", "history", "cli", "terminal", "sync"],
        "category": "shell history, developer productivity, and command search tooling",
        "target_customer": "individual developers and teams that live in the terminal",
        "ai_native_score": 1,
        "developer_tool_relevance": 5,
        "adoption_friction": 2,
        "likely_buyer": "individual developer or developer experience lead",
        "key_risk": "Developer love does not automatically translate into a large paid platform business.",
    },
    "Primitive": {
        "keywords": ["codebase", "repository", "search", "understand", "developer"],
        "category": "AI-assisted codebase understanding and developer workflow tooling",
        "target_customer": "software teams that need faster codebase onboarding and navigation",
        "ai_native_score": 4,
        "developer_tool_relevance": 4,
        "adoption_friction": 3,
        "likely_buyer": "engineering manager or developer productivity owner",
        "key_risk": "The product needs repeated workflow pull, not just a clever demo, to become enduring infrastructure.",
    },
    "Rasa": {
        "keywords": ["assistant", "chatbot", "conversational", "enterprise", "automation"],
        "category": "conversational AI and enterprise automation platform",
        "target_customer": "enterprises deploying assistants for support and internal operations",
        "ai_native_score": 4,
        "developer_tool_relevance": 3,
        "adoption_friction": 4,
        "likely_buyer": "head of support automation or enterprise platform lead",
        "key_risk": "The category is competitive and parts of the stack can feel less aligned with the newest developer-first AI workflows.",
    },
    "Entire": {
        "keywords": ["workflow", "operations", "employee", "automation", "productivity"],
        "category": "AI workflow automation and operating software",
        "target_customer": "operations teams trying to automate repetitive internal work",
        "ai_native_score": 3,
        "developer_tool_relevance": 1,
        "adoption_friction": 3,
        "likely_buyer": "operations leader or COO",
        "key_risk": "Product clarity and developer-tool relevance are less obvious from lightweight public descriptions alone.",
    },
    "Unknown": {
        "keywords": [],
        "category": "unclear software category",
        "target_customer": "unclear from the source text",
        "ai_native_score": 3,
        "developer_tool_relevance": 2,
        "adoption_friction": 3,
        "likely_buyer": "unclear buyer",
        "key_risk": "The source text is too ambiguous to support strong diligence confidence.",
    },
}


@dataclass
class StartupSignal:
    company_name: str
    website: str
    category: str
    target_customer: str
    product_summary: str
    ai_native_score: int
    developer_tool_relevance: int
    adoption_friction: int
    likely_buyer: str
    key_risk: str
    diligence_notes: str

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "StartupSignal":
        missing = [field for field in REQUIRED_FIELDS if field not in payload]
        extra = sorted(set(payload) - set(REQUIRED_FIELDS))
        if missing:
            raise ValueError(f"Missing required fields: {missing}")
        if extra:
            raise ValueError(f"Unexpected fields: {extra}")

        validated: dict[str, Any] = {}
        for field in REQUIRED_FIELDS:
            value = payload[field]
            if field in INT_FIELDS:
                if not isinstance(value, int):
                    raise TypeError(f"{field} must be an int")
                if not 1 <= value <= 5:
                    raise ValueError(f"{field} must be between 1 and 5")
            else:
                if not isinstance(value, str):
                    raise TypeError(f"{field} must be a string")
                value = collapse_whitespace(value)
                if not value:
                    raise ValueError(f"{field} may not be empty")
            validated[field] = value

        if not re.match(r"^https?://", validated["website"]):
            raise ValueError("website must start with http:// or https://")

        return cls(**validated)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def collapse_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def clamp(value: int, lower: int = 1, upper: int = 5) -> int:
    return max(lower, min(upper, value))


def normalize_url(url: str) -> str:
    cleaned = collapse_whitespace(url)
    if not cleaned:
        return "https://unknown.example"
    if not re.match(r"^https?://", cleaned):
        cleaned = f"https://{cleaned.lstrip('/')}"
    cleaned = cleaned.rstrip(".,;:!?)]}")
    return cleaned.rstrip("/")


def load_samples(path: str | Path) -> list[dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, list):
        raise ValueError("Dataset must be a list of samples")
    return payload


def save_json(path: str | Path, payload: dict[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def extract_website(text: str) -> str:
    match = re.search(r"(https?://[^\s,)\]]+|www\.[^\s,)\]]+)", text, flags=re.IGNORECASE)
    if match:
        return normalize_url(match.group(1))
    domain_match = re.search(r"\b([a-z0-9-]+\.(?:ai|com|dev|io|sh))\b", text, flags=re.IGNORECASE)
    if domain_match:
        return normalize_url(domain_match.group(1))
    return "https://unknown.example"


def infer_company_name(text: str, website: str) -> str:
    lowered = text.lower()
    for token, canonical in KNOWN_COMPANIES.items():
        if token in lowered or token in website.lower():
            return canonical

    title_case_match = re.search(
        r"\b([A-Z][A-Za-z0-9]+(?:\s+[A-Z][A-Za-z0-9]+){0,2})\b",
        text,
    )
    if title_case_match:
        return collapse_whitespace(title_case_match.group(1))
    return "Unknown"


def choose_profile(company_name: str, text: str) -> dict[str, Any]:
    if company_name in COMPANY_PROFILES:
        return copy.deepcopy(COMPANY_PROFILES[company_name])

    lowered = text.lower()
    best_match = "Unknown"
    best_score = 0
    for name, profile in COMPANY_PROFILES.items():
        score = sum(1 for keyword in profile["keywords"] if keyword in lowered)
        if score > best_score:
            best_match = name
            best_score = score
    return copy.deepcopy(COMPANY_PROFILES[best_match])


def infer_product_summary(text: str, company_name: str, profile: dict[str, Any]) -> str:
    sentences = [
        collapse_whitespace(sentence)
        for sentence in re.split(r"(?<=[.!?])\s+", text)
        if collapse_whitespace(sentence)
    ]
    chosen: list[str] = []
    for sentence in sentences:
        if len(chosen) == 2:
            break
        chosen.append(sentence)

    summary = " ".join(chosen)
    summary = re.sub(r"\s*[\[{(].*?[\]})]\s*", " ", summary)
    summary = collapse_whitespace(summary)

    if len(summary.split()) < 8:
        summary = (
            f"{company_name} appears to be a {profile['category']} product aimed at "
            f"{profile['target_customer']}."
        )
    return summary


def infer_target_customer(text: str, profile: dict[str, Any]) -> str:
    lowered = text.lower()
    if "developer" in lowered or "engineering" in lowered:
        return "software teams and engineers integrating the product into daily workflows"
    if "enterprise" in lowered:
        return "enterprise teams looking for higher reliability and operational control"
    if "operations" in lowered:
        return "operations teams automating repeatable work"
    return profile["target_customer"]


def infer_scores(text: str, company_name: str, profile: dict[str, Any], difficulty: str) -> tuple[int, int, int]:
    lowered = text.lower()
    ai_native = int(profile["ai_native_score"])
    developer_tool_relevance = int(profile["developer_tool_relevance"])
    friction = int(profile["adoption_friction"])

    if any(keyword in lowered for keyword in ["llm", "agent", "model", "copilot", "ai-native"]):
        ai_native = clamp(ai_native + 1)
    if any(keyword in lowered for keyword in ["sdk", "api", "cli", "framework", "infra"]):
        developer_tool_relevance = clamp(developer_tool_relevance + 1)
    if any(keyword in lowered for keyword in ["migration", "integration", "governance", "security", "deployment"]):
        friction = clamp(friction + 1)
    if difficulty == "adversarial":
        friction = clamp(friction + 1)
    if company_name == "Atuin":
        ai_native = 1

    return ai_native, developer_tool_relevance, friction


def infer_likely_buyer(text: str, profile: dict[str, Any], company_name: str) -> str:
    lowered = text.lower()
    if "cto" in lowered or "vp engineering" in lowered:
        return "senior engineering leadership"
    if "support" in lowered:
        return "head of support or automation owner"
    if company_name in {"BAML", "Mem0", "Primitive", "Atuin", "Parasail"}:
        return profile["likely_buyer"]
    if "platform" in lowered or "infra" in lowered:
        return "platform or infrastructure lead"
    return profile["likely_buyer"]


def infer_key_risk(text: str, difficulty: str, profile: dict[str, Any]) -> str:
    risk = profile["key_risk"]
    lowered = text.lower()
    if "open source" in lowered:
        risk = f"{risk} Open-source alternatives could also pressure pricing and differentiation."
    if "conflict" in lowered or "contradict" in lowered:
        risk = f"{risk} The source text also contains conflicting claims, which lowers confidence."
    elif difficulty == "adversarial":
        risk = f"{risk} The source text was intentionally noisy, which lowers confidence."
    return collapse_whitespace(risk)


def infer_notes(text: str, signal: dict[str, Any], difficulty: str) -> str:
    notes = [
        f"The strongest signal is the workflow pain around {signal['category']}.",
        f"The buyer most likely sits with {signal['likely_buyer']}.",
        f"Adoption friction looks like a {signal['adoption_friction']}/5 because teams would need to trust the product inside an existing stack.",
    ]
    lowered = text.lower()
    if any(keyword in lowered for keyword in ["unclear", "unknown", "???", "maybe", "conflicting"]):
        notes.append("The description is noisy, so I would want a tighter demo and clearer customer references before getting too confident.")
    if difficulty == "clean":
        notes.append("This input was well formed, so the extracted fields should be treated as higher confidence.")
    if difficulty == "messy":
        notes.append("Messy formatting did not block extraction, but it increased the need for conservative wording.")
    if difficulty == "adversarial":
        notes.append("I kept the output conservative because the text was designed to trigger schema drift and over-claiming.")
    return collapse_whitespace(" ".join(notes))


def build_candidate(sample: dict[str, Any]) -> dict[str, Any]:
    text = sample["raw_text"]
    difficulty = sample.get("difficulty", "clean")
    website = extract_website(text)
    company_name = infer_company_name(text, website)
    profile = choose_profile(company_name, text)
    target_customer = infer_target_customer(text, profile)
    ai_native, developer_tool_relevance, friction = infer_scores(text, company_name, profile, difficulty)

    candidate = {
        "company_name": company_name,
        "website": website,
        "category": profile["category"],
        "target_customer": target_customer,
        "product_summary": infer_product_summary(text, company_name, profile),
        "ai_native_score": ai_native,
        "developer_tool_relevance": developer_tool_relevance,
        "adoption_friction": friction,
        "likely_buyer": infer_likely_buyer(text, profile, company_name),
        "key_risk": infer_key_risk(text, difficulty, profile),
        "diligence_notes": "",
    }
    candidate["diligence_notes"] = infer_notes(text, candidate, difficulty)
    return candidate


def validate_signal(candidate: dict[str, Any]) -> StartupSignal:
    return StartupSignal.from_dict(candidate)


def extract_structured_signal(sample: dict[str, Any], provider_mode: str = "mock") -> dict[str, Any]:
    candidate = build_candidate(sample)
    signal = validate_signal(candidate)
    return {
        "provider_mode": provider_mode,
        "signal": signal.to_dict(),
        "audit": audit_signal(signal.to_dict(), sample.get("expected", {})),
        "limitations": (
            "This run used an offline mock provider because live BAML/OpenAI dependencies "
            "and API credentials were not available in the current environment."
            if provider_mode == "mock"
            else "This run used a live provider."
        ),
    }


def simulate_raw_llm_response(sample: dict[str, Any], run_index: int) -> str:
    candidate = build_candidate(sample)
    difficulty = sample.get("difficulty", "clean")
    mod = run_index % 3

    if difficulty == "clean":
        if mod == 0:
            return json.dumps(candidate, indent=2)
        if mod == 1:
            noisy = dict(candidate)
            noisy["venture_score"] = "promising"
            return "Here is the result:\n" + json.dumps(noisy)
        broken = json.dumps(candidate).replace('"adoption_friction": 3', '"adoption_friction": "3"')
        return broken

    if difficulty == "messy":
        if mod == 0:
            noisy = dict(candidate)
            noisy.pop("diligence_notes", None)
            return json.dumps(noisy)
        if mod == 1:
            return (
                "{company_name: "
                f"\"{candidate['company_name']}\", website: \"{candidate['website']}\", "
                f"category: \"{candidate['category']}\"}}"
            )
        noisy = dict(candidate)
        noisy["developer_tool_relevance"] = "high"
        return json.dumps(noisy)

    if mod == 0:
        noisy = dict(candidate)
        noisy["confidence"] = 0.99
        return "Maybe this startup is amazing.\n" + json.dumps(noisy)
    if mod == 1:
        noisy = dict(candidate)
        noisy["company_name"] = ""
        noisy["ai_native_score"] = 8
        return json.dumps(noisy)
    return (
        "{\n"
        f'  "company_name": "{candidate["company_name"]}",\n'
        f'  "website": "{candidate["website"]}",\n'
        f'  "category": "{candidate["category"]}"\n'
        "  \"target_customer\": \"missing comma case\"\n"
        "}"
    )


def try_parse_baseline(raw_response: str) -> dict[str, Any]:
    try:
        payload = json.loads(raw_response)
        return {"json_valid": True, "parsed": payload, "error": None}
    except json.JSONDecodeError as exc:
        return {"json_valid": False, "parsed": None, "error": str(exc)}


def audit_signal(signal: dict[str, Any], expected: dict[str, Any]) -> dict[str, Any]:
    issues: list[str] = []

    expected_company = expected.get("company_name")
    if expected_company and signal["company_name"] != expected_company:
        issues.append(f"Expected company_name {expected_company}, got {signal['company_name']}")

    expected_website = expected.get("website")
    if expected_website and normalize_url(signal["website"]) != normalize_url(expected_website):
        issues.append(f"Expected website {expected_website}, got {signal['website']}")

    category_keyword = expected.get("category_keyword")
    if category_keyword and category_keyword.lower() not in signal["category"].lower():
        issues.append(f"Expected category to mention {category_keyword}")

    buyer_keyword = expected.get("buyer_keyword")
    if buyer_keyword and buyer_keyword.lower() not in signal["likely_buyer"].lower():
        issues.append(f"Expected likely_buyer to mention {buyer_keyword}")

    notes_length = len(signal["diligence_notes"].split())
    if notes_length < 20:
        issues.append("Diligence notes are too thin to be useful.")

    return {
        "passed": not issues,
        "issues": issues,
    }


def run_dataset(path: str | Path, provider_mode: str = "mock", repeated_runs: int = 3) -> dict[str, Any]:
    samples = load_samples(path)
    dataset_name = Path(path).stem.replace("_startup_descriptions", "")
    items: list[dict[str, Any]] = []

    for sample in samples:
        structured_runs = [
            extract_structured_signal(sample, provider_mode=provider_mode)["signal"]
            for _ in range(repeated_runs)
        ]
        baseline_runs = []
        for run_index in range(repeated_runs):
            raw_response = simulate_raw_llm_response(sample, run_index)
            baseline_runs.append(
                {
                    "run_index": run_index + 1,
                    "raw_response": raw_response,
                    **try_parse_baseline(raw_response),
                }
            )

        structured_result = extract_structured_signal(sample, provider_mode=provider_mode)
        items.append(
            {
                "sample_id": sample["sample_id"],
                "difficulty": sample.get("difficulty", dataset_name),
                "raw_text": sample["raw_text"],
                "expected": sample.get("expected", {}),
                "structured_output": structured_result["signal"],
                "structured_runs": structured_runs,
                "structured_audit": structured_result["audit"],
                "baseline_runs": baseline_runs,
            }
        )

    return {
        "dataset": dataset_name,
        "provider_mode": provider_mode,
        "repeated_runs": repeated_runs,
        "items": items,
    }


def canonical_json(payload: dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, ensure_ascii=False)


def load_output(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)
