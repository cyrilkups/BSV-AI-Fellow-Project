from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core import StartupSignal, extract_website, normalize_url, load_samples, run_dataset  # noqa: E402
from evaluator import evaluate_baseline_runs, evaluate_structured_item  # noqa: E402


class PrototypeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.prototype_dir = Path(__file__).resolve().parents[1]

    def test_validation_rejects_out_of_range_scores(self) -> None:
        with self.assertRaises(ValueError):
            StartupSignal.from_dict(
                {
                    "company_name": "Example",
                    "website": "https://example.com",
                    "category": "developer tool",
                    "target_customer": "developers",
                    "product_summary": "Example summary for a product.",
                    "ai_native_score": 6,
                    "developer_tool_relevance": 4,
                    "adoption_friction": 3,
                    "likely_buyer": "engineering lead",
                    "key_risk": "Too many unknowns.",
                    "diligence_notes": "These notes are long enough to count as useful for the test.",
                }
            )

    def test_structured_extraction_returns_all_required_fields(self) -> None:
        output = run_dataset(
            self.prototype_dir / "input_examples" / "clean_startup_descriptions.json",
            repeated_runs=3,
        )
        item = output["items"][0]
        structured = evaluate_structured_item(item)
        self.assertTrue(structured["required_fields_present"])
        self.assertTrue(structured["consistent_across_runs"])
        self.assertTrue(structured["diligence_notes_useful"])

    def test_baseline_runs_expose_failures(self) -> None:
        output = run_dataset(
            self.prototype_dir / "input_examples" / "adversarial_startup_descriptions.json",
            repeated_runs=3,
        )
        item = output["items"][0]
        baseline = evaluate_baseline_runs(item)
        self.assertFalse(baseline["consistent_across_runs"])
        self.assertGreaterEqual(len(baseline["parse_errors"]) + baseline["type_failures"], 1)

    def test_clean_dataset_structured_audits_pass(self) -> None:
        output = run_dataset(
            self.prototype_dir / "input_examples" / "clean_startup_descriptions.json",
            repeated_runs=3,
        )
        self.assertTrue(all(item["structured_audit"]["passed"] for item in output["items"]))

    def test_all_datasets_pass_structured_validation_and_audit(self) -> None:
        dataset_names = [
            "clean_startup_descriptions.json",
            "messy_startup_descriptions.json",
            "adversarial_startup_descriptions.json",
        ]
        for dataset_name in dataset_names:
            with self.subTest(dataset=dataset_name):
                output = run_dataset(
                    self.prototype_dir / "input_examples" / dataset_name,
                    repeated_runs=5,
                )
                for item in output["items"]:
                    structured = evaluate_structured_item(item)
                    self.assertTrue(structured["valid_json"])
                    self.assertTrue(structured["required_fields_present"])
                    self.assertTrue(structured["type_correct"])
                    self.assertTrue(structured["consistent_across_runs"])
                    self.assertTrue(structured["diligence_notes_useful"])
                    self.assertTrue(item["structured_audit"]["passed"], item["structured_audit"]["issues"])

    def test_run_dataset_honors_requested_repeated_runs(self) -> None:
        output = run_dataset(
            self.prototype_dir / "input_examples" / "adversarial_startup_descriptions.json",
            repeated_runs=12,
        )
        self.assertEqual(output["repeated_runs"], 12)
        for item in output["items"]:
            self.assertEqual(len(item["structured_runs"]), 12)
            self.assertEqual(len(item["baseline_runs"]), 12)
            self.assertTrue(all(run == item["structured_output"] for run in item["structured_runs"]))

    def test_website_extraction_normalizes_bare_domains_and_punctuation(self) -> None:
        self.assertEqual(normalize_url("boundaryml.com..."), "https://boundaryml.com")
        self.assertEqual(extract_website("See docs at https://mem0.ai, it looks promising."), "https://mem0.ai")
        self.assertEqual(extract_website("website primitive.dev)"), "https://primitive.dev")

    def test_dataset_contains_samples(self) -> None:
        samples = load_samples(self.prototype_dir / "input_examples" / "messy_startup_descriptions.json")
        self.assertEqual(len(samples), 3)


if __name__ == "__main__":
    unittest.main()
