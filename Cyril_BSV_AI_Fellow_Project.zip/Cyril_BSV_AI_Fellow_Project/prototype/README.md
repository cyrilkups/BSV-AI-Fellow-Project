# Startup Signal Extractor

## Overview
This prototype tests a simple version of the core BAML thesis: structured interfaces make LLM outputs easier to trust inside normal software systems.

The current submission runs in an offline mock mode because this environment does not have live API credentials or BAML installed. The extraction path is still typed and validated, and the evaluator compares it against a brittle raw-output baseline to show where schema discipline helps.

## Files That Matter
- `main.py`: runs the extraction pipeline on clean, messy, and adversarial inputs.
- `evaluator.py`: audits outputs for JSON validity, schema coverage, type correctness, repeated-run consistency, and diligence note usefulness.
- `core.py`: contains the extraction heuristics, validation logic, and baseline simulation.
- `input_examples/`: labeled test inputs.
- `outputs/`: generated run artifacts.
- `baml_src/`: optional real BAML sketch for the same task.

## How To Run
From this `prototype/` directory:

```bash
pip install -r requirements.txt
python3 main.py
python3 evaluator.py
python3 -m unittest discover -s tests
```

## Notes
This is intentionally not production-grade extraction software. The point is to test reliability, failure handling, and developer experience around typed structured output workflows.
