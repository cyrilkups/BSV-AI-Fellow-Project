from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from core import REQUIRED_FIELDS, canonical_json, load_output, validate_signal


def notes_usefulness_score(notes: str) -> int:
    score = 0
    word_count = len(notes.split())
    if word_count >= 20:
        score += 1
    if "risk" in notes.lower() or "confidence" in notes.lower() or "buyer" in notes.lower():
        score += 1
    if "adoption" in notes.lower() or "workflow" in notes.lower():
        score += 1
    return score


def evaluate_structured_item(item: dict[str, Any]) -> dict[str, Any]:
    signal = item["structured_output"]
    validate_signal(signal)
    missing = [field for field in REQUIRED_FIELDS if field not in signal]
    extras = sorted(set(signal) - set(REQUIRED_FIELDS))

    consistency = len({canonical_json(run) for run in item["structured_runs"]}) == 1
    usefulness = notes_usefulness_score(signal["diligence_notes"])

    return {
        "valid_json": True,
        "required_fields_present": not missing,
        "missing_fields": missing,
        "hallucinated_fields": extras,
        "type_correct": True,
        "consistent_across_runs": consistency,
        "diligence_notes_useful": usefulness >= 2,
        "diligence_notes_score": usefulness,
    }


def evaluate_baseline_runs(item: dict[str, Any]) -> dict[str, Any]:
    valid_runs = 0
    required_field_failures = 0
    type_failures = 0
    extras_seen: set[str] = set()
    run_payloads: list[str] = []
    parse_errors: list[str] = []

    for run in item["baseline_runs"]:
        if not run["json_valid"]:
            parse_errors.append(run["error"] or "Unknown JSON parsing error")
            continue

        payload = run["parsed"]
        run_payloads.append(json.dumps(payload, sort_keys=True))
        missing = [field for field in REQUIRED_FIELDS if field not in payload]
        if missing:
            required_field_failures += 1
            continue

        try:
            validate_signal(payload)
            valid_runs += 1
        except (TypeError, ValueError):
            type_failures += 1

        extras_seen.update(sorted(set(payload) - set(REQUIRED_FIELDS)))

    consistent = len(run_payloads) >= 2 and len(set(run_payloads)) == 1
    return {
        "valid_runs": valid_runs,
        "required_field_failures": required_field_failures,
        "type_failures": type_failures,
        "hallucinated_fields": sorted(extras_seen),
        "consistent_across_runs": consistent,
        "parse_errors": parse_errors,
    }


def summarize_dataset(path: Path) -> dict[str, Any]:
    output = load_output(path)
    structured_valid = 0
    structured_consistent = 0
    common_failures: list[str] = []
    baseline_parse_failures = 0
    baseline_valid = 0

    for item in output["items"]:
        structured = evaluate_structured_item(item)
        baseline = evaluate_baseline_runs(item)

        if structured["valid_json"] and structured["required_fields_present"] and structured["type_correct"]:
            structured_valid += 1
        if structured["consistent_across_runs"]:
            structured_consistent += 1

        baseline_parse_failures += len(baseline["parse_errors"])
        baseline_valid += baseline["valid_runs"]

        if baseline["parse_errors"]:
            common_failures.append("baseline JSON parsing drift")
        if baseline["required_field_failures"]:
            common_failures.append("missing required fields in baseline runs")
        if baseline["type_failures"]:
            common_failures.append("type mismatches in baseline runs")
        if baseline["hallucinated_fields"]:
            common_failures.append("hallucinated extra keys in baseline runs")

    deduped_failures = ", ".join(sorted(set(common_failures))) or "None in structured path"
    notes = (
        f"Structured path stayed valid on {structured_valid}/{len(output['items'])} samples and "
        f"consistent on {structured_consistent}/{len(output['items'])}. "
        f"Simulated raw baseline produced {baseline_valid} fully valid runs and {baseline_parse_failures} parse failures."
    )

    return {
        "dataset": output["dataset"],
        "inputs_tested": len(output["items"]),
        "valid_outputs": structured_valid,
        "common_failures": deduped_failures,
        "notes": notes,
    }


def render_summary_markdown(summaries: list[dict[str, Any]]) -> str:
    lines = [
        "# Evaluation Summary",
        "",
        "| Test Type | Inputs Tested | Valid Outputs | Common Failures | Notes |",
        "|---|---:|---:|---|---|",
    ]
    for summary in summaries:
        lines.append(
            f"| {summary['dataset'].title()} | {summary['inputs_tested']} | {summary['valid_outputs']} | "
            f"{summary['common_failures']} | {summary['notes']} |"
        )

    lines.extend(
        [
            "",
            "## Qualitative Observations",
            "",
            "### What worked well",
            "The typed extraction path kept every sample schema-valid and stable across repeated runs, even when the raw text quality dropped.",
            "",
            "### What broke",
            "The simulated raw baseline frequently drifted into malformed JSON, missing fields, and extra keys. Adversarial inputs also made company identity resolution less certain.",
            "",
            "### What surprised me",
            "Messy descriptions were still recoverable as long as a few high-signal anchors remained, especially the domain name and clear workflow keywords.",
            "",
            "### What I would improve with more time",
            "I would swap the mock provider for live BAML and OpenAI runs, add side-by-side benchmark prompts, and score outputs against a larger labeled dataset.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    project_root = Path(__file__).resolve().parent
    output_dir = project_root / "outputs"
    paths = [
        output_dir / "clean_run_output.json",
        output_dir / "messy_run_output.json",
        output_dir / "adversarial_run_output.json",
    ]

    summaries = [summarize_dataset(path) for path in paths]
    summary_markdown = render_summary_markdown(summaries)
    target = output_dir / "evaluation_summary.md"
    target.write_text(summary_markdown + "\n", encoding="utf-8")
    print(f"Wrote {target.name}.")


if __name__ == "__main__":
    main()
