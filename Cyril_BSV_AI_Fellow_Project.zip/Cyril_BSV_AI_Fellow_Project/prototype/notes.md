# Prototype Notes

## Environment Constraint
I could not run a live BAML or OpenAI-backed extraction flow in this workspace because the required packages and API credentials were not present. I therefore implemented a BAML-inspired typed extraction layer that is fully runnable offline and clearly marks the limitation in the writeup.

## Testing Intent
The evaluator is designed to answer the practical questions I would care about during diligence:
- Does the structured path always return valid JSON?
- Are all required diligence fields present?
- Are numeric scores kept in range and string fields normalized?
- Does a looser raw-output baseline drift across repeated runs?
- Are the diligence notes actually useful enough to support follow-up work?

## Real BAML Extension Path
If I were continuing this project, the next step would be to install `baml-py`, generate a `baml_client`, and point the same datasets at live model-backed extraction so the reliability claims are grounded in real calls rather than a simulated baseline.
