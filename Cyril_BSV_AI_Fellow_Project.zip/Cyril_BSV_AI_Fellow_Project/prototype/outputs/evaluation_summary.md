# Evaluation Summary

| Test Type | Inputs Tested | Valid Outputs | Common Failures | Notes |
|---|---:|---:|---|---|
| Clean | 3 | 3 | baseline JSON parsing drift, type mismatches in baseline runs | Structured path stayed valid on 3/3 samples and consistent on 3/3. Simulated raw baseline produced 4 fully valid runs and 3 parse failures. |
| Messy | 3 | 3 | baseline JSON parsing drift, missing required fields in baseline runs, type mismatches in baseline runs | Structured path stayed valid on 3/3 samples and consistent on 3/3. Simulated raw baseline produced 0 fully valid runs and 3 parse failures. |
| Adversarial | 3 | 3 | baseline JSON parsing drift, type mismatches in baseline runs | Structured path stayed valid on 3/3 samples and consistent on 3/3. Simulated raw baseline produced 0 fully valid runs and 6 parse failures. |

## Qualitative Observations

### What worked well
The typed extraction path kept every sample schema-valid and stable across repeated runs, even when the raw text quality dropped.

### What broke
The simulated raw baseline frequently drifted into malformed JSON, missing fields, and extra keys. Adversarial inputs also made company identity resolution less certain.

### What surprised me
Messy descriptions were still recoverable as long as a few high-signal anchors remained, especially the domain name and clear workflow keywords.

### What I would improve with more time
I would swap the mock provider for live BAML and OpenAI runs, add side-by-side benchmark prompts, and score outputs against a larger labeled dataset.

