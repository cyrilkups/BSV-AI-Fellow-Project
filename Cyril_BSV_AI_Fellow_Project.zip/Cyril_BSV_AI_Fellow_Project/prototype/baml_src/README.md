# Optional Real BAML Sketch

This folder contains a draft BAML version of the same extraction task. I did not execute it in this environment because `baml-py` and the generated `baml_client` were not available locally.

The official Boundary docs describe the high-level flow as:
1. Install `baml-py`
2. Run `baml-cli init`
3. Add a `generator` block and BAML functions
4. Run `baml-cli generate`
5. Call the generated `baml_client` from Python

Sources:
- https://docs.boundaryml.com/guide/installation-language/python
- https://docs.boundaryml.com/guide/introduction/what-is-baml
- https://docs.boundaryml.com/ref/baml/test
