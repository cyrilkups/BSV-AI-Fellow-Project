from __future__ import annotations

from pathlib import Path
from textwrap import wrap


PAGE_WIDTH = 612
PAGE_HEIGHT = 792
LEFT_MARGIN = 50
TOP_MARGIN = 742
BOTTOM_MARGIN = 50
FONT_SIZE = 10
LEADING = 14
MAX_CHARS = 92


def escape_pdf_text(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def normalize_markdown(text: str) -> list[str]:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    lines: list[str] = []
    for raw_line in normalized.split("\n"):
        line = raw_line.expandtabs(4)
        if not line.strip():
            lines.append("")
            continue
        if line.startswith("#"):
            line = line.lstrip("#").strip().upper()
        wrapped = wrap(line, width=MAX_CHARS, break_long_words=False, replace_whitespace=False)
        lines.extend(wrapped or [""])
    return lines


def paginate(lines: list[str]) -> list[list[str]]:
    max_lines = int((TOP_MARGIN - BOTTOM_MARGIN) / LEADING)
    return [lines[index:index + max_lines] for index in range(0, len(lines), max_lines)] or [[]]


def build_page_stream(lines: list[str]) -> bytes:
    commands = ["BT", f"/F1 {FONT_SIZE} Tf", f"{LEFT_MARGIN} {TOP_MARGIN} Td", f"{LEADING} TL"]
    first = True
    for line in lines:
        escaped = escape_pdf_text(line)
        if first:
            commands.append(f"({escaped}) Tj")
            first = False
        else:
            commands.append("T*")
            commands.append(f"({escaped}) Tj")
    commands.append("ET")
    return "\n".join(commands).encode("latin-1", errors="replace")


def write_pdf_from_markdown(source: Path, target: Path) -> None:
    lines = normalize_markdown(source.read_text(encoding="utf-8"))
    pages = paginate(lines)

    objects: list[bytes] = []

    def add_object(payload: bytes) -> int:
        objects.append(payload)
        return len(objects)

    font_id = add_object(b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>")
    page_ids: list[int] = []
    content_ids: list[int] = []

    placeholder_pages_id = add_object(b"<< /Type /Pages /Count 0 /Kids [] >>")

    for page_lines in pages:
        content_stream = build_page_stream(page_lines)
        content_id = add_object(
            f"<< /Length {len(content_stream)} >>\nstream\n".encode("latin-1")
            + content_stream
            + b"\nendstream"
        )
        page_id = add_object(
            (
                f"<< /Type /Page /Parent {placeholder_pages_id} 0 R "
                f"/MediaBox [0 0 {PAGE_WIDTH} {PAGE_HEIGHT}] "
                f"/Resources << /Font << /F1 {font_id} 0 R >> >> "
                f"/Contents {content_id} 0 R >>"
            ).encode("latin-1")
        )
        content_ids.append(content_id)
        page_ids.append(page_id)

    kids = " ".join(f"{page_id} 0 R" for page_id in page_ids)
    objects[placeholder_pages_id - 1] = (
        f"<< /Type /Pages /Count {len(page_ids)} /Kids [{kids}] >>".encode("latin-1")
    )

    catalog_id = add_object(f"<< /Type /Catalog /Pages {placeholder_pages_id} 0 R >>".encode("latin-1"))

    output = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for index, payload in enumerate(objects, start=1):
        offsets.append(len(output))
        output.extend(f"{index} 0 obj\n".encode("latin-1"))
        output.extend(payload)
        output.extend(b"\nendobj\n")

    xref_offset = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n".encode("latin-1"))
    output.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode("latin-1"))
    output.extend(
        (
            f"trailer\n<< /Size {len(objects) + 1} /Root {catalog_id} 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF\n"
        ).encode("latin-1")
    )

    target.write_bytes(output)


def main() -> None:
    root = Path(__file__).resolve().parent
    exports = {
        root / "1_Prioritization_Framework.md": root / "final_exports" / "Prioritization_Framework.pdf",
        root / "2_BAML_Lightweight_Diligence.md": root / "final_exports" / "BAML_Lightweight_Diligence.pdf",
        root / "3_LLM_Conversation_Transcript.md": root / "final_exports" / "LLM_Conversation.pdf",
    }
    for source, target in exports.items():
        write_pdf_from_markdown(source, target)
        print(f"Wrote {target.name}")


if __name__ == "__main__":
    main()
